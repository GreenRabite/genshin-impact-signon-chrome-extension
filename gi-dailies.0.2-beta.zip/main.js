(function () {
  const URL = "https://webstatic-sea.mihoyo.com/ys/event/signin-sea/index.html?act_id=e202102251931481"
  window.open(URL, "_blank")
})();